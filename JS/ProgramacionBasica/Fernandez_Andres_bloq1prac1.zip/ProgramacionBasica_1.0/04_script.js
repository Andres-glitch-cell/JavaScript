let numeroUsuario = prompt("Introduce un número y dime si es par o impar: ")

if (numeroUsuario % 2 == 0) {
    alert("El número " + numeroUsuario + " es par")
} else {
    alert("El número " + numeroUsuario + " es impar");
}